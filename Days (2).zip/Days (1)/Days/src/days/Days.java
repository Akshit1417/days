/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package days;

import java.util.Scanner;

/**
 *
 * @author akshitsharma
 */


public class Days {
    public static void main(String[] args) {
        Weekdays weekdays = new Weekdays();
        weekdays.printAllDays();
    }
}

